#     The #1 Multi-tool for Discord.  
<p align="center">             
  <h3 align="center"></h3>
    <a href="https://discord.gg/nuking">Join the discord</a>
  </p>
</p>

<details open="open">
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#about-the-project">About The Project</a>
      <ul>
      </ul>
    </li>
    <li>
      <a href="#getting-started">Getting Started</a>
      <ul>
        <li><a href="#installation">Installation</a></li>
      </ul>
    </li>
  </ol>
</details>

## About The Project

![cmd_n6qNOMbmTh](https://github.com/Venaste/Gloom/assets/165221254/82298cf1-555d-4cae-abdb-3ab207e5a8e8)


### The tool has all the features you need to run and raid a discord server  

+ Bomb account
+ Unfriend everyone
+ Delete all servers
+ Spam new servers
+ Delete all dms
+ DM everyone
+ Enable lightning (aka seizure mode)
+ Token info
+ Login with token
+ Block friends
+ Profile changer
+ IP pinger
+ Token grabber
+ QR grabbermass reporter
+ Groupchat creator
+ Webhook compromiser
+ Discord acc method
+ Bot nuker
+ Server lookup
+ Token checker
+ Server joiner



### Upcoming Features

- Faster Bot Nuker
- Token Generator

## Getting Started

1. Get a local copy up (download as .zip & extract) and running follow these simple steps.

### Installation

2. Open *Start.bat*
</br>   **If it doesn't open the tool:**
    
      3. Download all of the requirements in req.txt (manually or by opening setup.bat and letting it run though)

4. Open Start.bat to run the tool

5. Note: Make sure that you have Python installed...

For support join the discord!

### Q&A

Why is it detecting it as a virus/dangerous?

- Simple answer: The tool got an option build in that lets you build your own custom rat. That means that the tool got code in it to for example steal discord tokens etc, and thats why its getting detected. 

## Disclaimer

This code was made for Educational purposes
This project was created only for good purposes and personal use.
By using this project, you agree that you hold responsibility and accountability of any consequences caused by your actions.
