$HOTTAS MULTI TOOL MADE BY DEVZ.$OS

Requirements
Python
A PC or laptop.
a brain.
